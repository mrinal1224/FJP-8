export const API_KEY = ``;
export const endpoint = `https://newsapi.org/v2/top-headlines`;
export const category = 'general';
export const country = 'in'
